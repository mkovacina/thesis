function [x, best, gens] = crunch(filename,n_Solutions,n_Generations, cols)
% This is assuming that each generation in the data
% file is sorted, thus the first entry is the best

x = load(filename);

best = x(1:n_Solutions:n_Solutions*n_Generations,cols);

% this is done cols(:)' because the for picks of by the column, not the element, thus this ensures that the input to i is a row vector
for i=1:numel(cols(:))
  c1 = x(:,cols(i));
  [r, c] = size(c1);
  n_Gen = r / n_Solutions;
  gens(:,:,i) = reshape(c1,n_Solutions,n_Gen);
end 
%c2 = x(:,4);
%[r,c] = size(c2);
%n_Gen = r / n_Solutions;
%c2 = reshape(c2,n_Solutions,n_Gen); 

%plot(max(c1),'b');
%plot(max(c2),'g');
%plot(mean(c1),'b');
%plot(mean(c2),'g');
