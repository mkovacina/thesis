function oc_best

%%% [1] Get the data
[x, best, gens] = crunch("c[2005-03-02]-14.02.04/ga-data.dat",73,22,[3 4 5]);
nbest=best./repmat([50 50 -299],22,1);
nbest(:,3) = 1-nbest(:,3);

%%% [2] Reset Gnuplot

graw("reset;");
clearplot;

%%% [3] Define decorations and plot area
gset title "Best solutions for Object Collection";
gset xlabel "Generation";
gset ylabel "Normalized Performance";
gset key bottom right;
gset xrange [1 : 25];
gset yrange [0 : 1.1];

%%% [4] Plot data
hold on;
gplot nbest(:,3) title "Time" with line;
gplot nbest(:,2) title "Objects Located" with line;
gplot nbest(:,1) title "Objects Returned" with line;

hold off;


%%% [5] Switch to PostScript output and plot into file
gset terminal push;
gset terminal postscript eps color;
gset output "oc_best.eps";
closeplot;
#replot;
#gset terminal pop;
#gset output;

