### [1] Get the data
[x, best, gens] = crunch("d[2005-03-01]-21.54.07/ga-data.dat",73,22,[3 4 5]);

mC = mean( gens(:,:,1) )/30;
mL = mean( gens(:,:,2) )/30;
mT = 1-mean( gens(:,:,3) )/-299;

mC = mC';
mL = mL';
mT = mT';

### [2] Reset Gnuplot

graw("reset;");
clearplot;

### [3] Define decorations and plot area
gset title "Mean Scores for Object Destruction";
gset xlabel "Generation";
gset ylabel "Normalized Performance";
gset key bottom right;
gset xrange [1 : 25];
gset yrange [0 : 1.1];

### [4] Plot data
hold on;
gplot mT title "Time" with line;
gplot mL title "Objects Located" with line;
gplot mC title "Objects Destroyed" with line;

hold off;


### [5] Switch to PostScript output and plot into file
gset terminal push;
gset terminal postscript eps color;
gset output "od_mean.eps";
closeplot;
#replot;
#gset terminal pop;
#gset output;

