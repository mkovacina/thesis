n_gen = 91;

### [1] Get the data
[x, best, gens] = crunch("mm[2005-03-05]-10.50.19/ga-data.dat",73,n_gen,[7 8 9 10 11 3 4 5 6]);
nbest=best;
nbest(:,5) = nbest(:,5)/-399;
nbest(:,5) = 1-nbest(:,5);

### [2] Reset Gnuplot

graw("reset;");
clearplot;

### [3] Define decorations and plot area
gset title "Best solutions for Object Manipulation";
gset xlabel "Generation";
gset ylabel "Normalized Performance";
gset key bottom right;
gset xrange [1 : n_gen];
gset yrange [0 : 1.1];

### [4] Plot data
hold on;
gplot nbest(:,5) title "t" with line;
gplot nbest(:,4) title "m_8" with line;
gplot nbest(:,3) title "m_7" with line;
gplot nbest(:,2) title "m_6" with line;
gplot nbest(:,1) title 'm_5' with line;

hold off;


### [5] Switch to PostScript output and plot into file
gset terminal push;
gset terminal postscript eps color;
gset output "om_best.eps";
closeplot;
#replot;
#gset terminal pop;
#gset output;


########################

m5 = mean( gens(:,:,1) );
m6 = mean( gens(:,:,2) );
m7 = mean( gens(:,:,3) );
m8 = mean( gens(:,:,4) );

m5 = m5';
m6 = m6';
m7 = m7';
m8 = m8';

graw("reset;");
clearplot;

### [3] Define decorations and plot area
gset title "Mean scores for Object Manipulation";
gset xlabel "Generation";
gset ylabel "Normalized Performance";
gset key bottom right;
gset xrange [1 : n_gen];
gset yrange [0 : 1.1];

### [4] Plot data
hold on;
gplot m5 title "m_5" with line;
gplot m6 title "m_6" with line;
gplot m7 title "m_7" with line;
gplot m8 title 'm_8' with line;

### [5] Switch to PostScript output and plot into file
gset terminal push;
gset terminal postscript eps color;
gset output "om_mean.eps";
closeplot;
#replot;
#gset terminal pop;
#gset output;

############################################

m1 = sum( gens( :, :, 1 ) );
m2 = sum( gens( :, :, 2 ) );
m3 = sum( gens( :, :, 3 ) );
m4 = sum( gens( :, :, 4 ) );


m1 = m1';
m2 = m2';
m3 = m3';
m4 = m4';

graw("reset;");
clearplot;

### [3] Define decorations and plot area
gset title "Number of solutions satisfying some criteria for Obect Manipulation";
gset xlabel "Generation";
gset ylabel "Normalized Performance";
gset key bottom right;
gset xrange [1 : n_gen];
gset yrange [0 : max(max(gens(:,:,1:4)))];

### [4] Plot data
hold on;
gplot m1 title 'm_1' with line;
gplot m2 title 'm_2' with line;
gplot m3 title 'm_3' with line;
gplot m4 title 'm_4' with line;

gset terminal push;
gset terminal postscript eps color;
gset output "om_sum.eps";
closeplot;

