### [1] Get the data
[x, best, gens] = crunch("c[2005-03-02]-14.02.04/ga-data.dat",73,22,[3 4 5]);

mC = mean( gens(:,:,1) )/50;
mL = mean( gens(:,:,2) )/50;
mT = 1-mean( gens(:,:,3) )/-299;

mC = mC';
mL = mL';
mT = mT';

### [2] Reset Gnuplot

graw("reset;");
clearplot;

### [3] Define decorations and plot area
gset title "Mean Scores for Object Collection";
gset xlabel "Generation";
gset ylabel "Normalized Performance";
gset key bottom right;
gset xrange [1 : 25];
gset yrange [0 : 1.1];

### [4] Plot data
hold on;
gplot mT title "Time" with line;
gplot mL title "Objects Located" with line;
gplot mC title "Objects Returned" with line;

hold off;


### [5] Switch to PostScript output and plot into file
gset terminal push;
gset terminal postscript eps color;
gset output "oc_mean.eps";
closeplot;
#replot;
#gset terminal pop;
#gset output;

